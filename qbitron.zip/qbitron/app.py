from flask import Flask, render_template, jsonify, request, send_from_directory, send_file
from io import BytesIO
import base64
import numpy as np
import json
import base64
import io
import os
from datetime import datetime
from matplotlib.figure import Figure
import matplotlib.pyplot as plt
import matplotlib.ticker
import scipy.special
from modulation import Modulator, ModulationType
from channel import Channel, ChannelType
from typing import Dict, Tuple, List, Any, Optional, Union
import traceback

# Configure matplotlib to use 'Agg' backend for non-interactive plotting
plt.switch_backend('Agg')

# Constants
DEFAULT_NUM_BITS = 1000
MAX_MESSAGE_BITS = 10000  # Limit for custom messages to prevent abuse

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max upload size

# Initialize default parameters
default_params = {
    'modulation': 'BPSK',
    'coding': 'none',
    'channel': 'AWGN',
    'snr_db': 10,
    'message': 'Digital Communication System',
    'use_random': True,
    'num_bits': 1000,
    'num_symbols': 1000,
    'show_theory': True,
    'auto_scale': True
}

# Simulation history (in-memory, consider a database for production)
simulation_history = []
MAX_HISTORY_ITEMS = 10  # Keep only the last 10 simulations

@app.route('/')
def index():
    """Render the main application page."""
    return render_template('index.html', 
                         title='Digital Communication System Simulator',
                         description='Interactive simulation of digital communication systems with BPSK, QPSK, and 16-QAM modulations.'
                         )

@app.route('/about')
def about():
    """Render the about page."""
    return render_template('about.html', 
                         title='About - Digital Communication System Simulator',
                         description='Learn about digital communication systems and how this simulator works.'
                         )

@app.route('/documentation')
def documentation():
    """Render the documentation page."""
    return render_template('documentation.html', 
                         title='Documentation - Digital Communication System Simulator',
                         description='Comprehensive documentation for the digital communication system simulator.'
                         )

@app.route('/api/modulation/types', methods=['GET'])
def get_modulation_types():
    """API endpoint to get available modulation types."""
    return jsonify({
        'modulation_types': [m.name for m in ModulationType],
        'default': default_params['modulation']
    })

@app.route('/api/channel/types', methods=['GET'])
def get_channel_types():
    """API endpoint to get available channel types."""
    return jsonify({
        'channel_types': [c.name for c in ChannelType],
        'default': default_params['channel']
    })

@app.route('/api/coding/types', methods=['GET'])
def get_coding_types():
    """API endpoint to get available coding types."""
    return jsonify({
        'coding_types': ['none', 'convolutional', 'reed-solomon'],
        'default': default_params['coding']
    })

@app.route('/api/simulation/history', methods=['GET'])
def get_simulation_history():
    """API endpoint to get simulation history."""
    return jsonify({
        'history': simulation_history[-MAX_HISTORY_ITEMS:],  # Return only recent items
        'count': len(simulation_history)
    })

@app.route('/simulate', methods=['POST'])
def simulate():
    """Main simulation endpoint that processes the simulation request and returns results."""
    try:
        # Get parameters from request
        params = request.get_json()
        
        # Validate and set default parameters
        for key in default_params:
            if key not in params:
                params[key] = default_params[key]
        
        # Convert parameter types
        try:
            params['snr_db'] = float(params['snr_db'])
            params['num_bits'] = int(params.get('num_bits', default_params['num_bits']))
            params['use_random'] = bool(params.get('use_random', default_params['use_random']))
        except (ValueError, TypeError) as e:
            return jsonify({
                'error': 'Invalid parameter values',
                'details': str(e)
            }), 400
        
        # Generate random bits or convert message to bits
        if params['use_random'] or not params['message']:
            bits = np.random.randint(0, 2, int(params['num_bits']))
            message = None
        else:
            # Convert message to binary
            message = str(params['message'])
            # Limit message length to prevent excessive memory usage
            max_chars = MAX_MESSAGE_BITS // 8  # 8 bits per character
            if len(message) > max_chars:
                message = message[:max_chars]
            
            # Convert message to bits (UTF-8 encoding)
            bits = np.unpackbits(np.frombuffer(message.encode('utf-8'), dtype=np.uint8))
            
            # Truncate or pad to match num_bits if specified
            if 'num_bits' in params and params['num_bits'] > 0:
                if len(bits) > params['num_bits']:
                    bits = bits[:params['num_bits']]
                elif len(bits) < params['num_bits']:
                    # Pad with random bits if needed
                    padding = np.random.randint(0, 2, params['num_bits'] - len(bits))
                    bits = np.concatenate((bits, padding))
        
        # Initialize modulator
        try:
            modulator = Modulator()
            modulator.modulation_type = ModulationType[params['modulation']]
        except KeyError:
            return jsonify({
                'error': 'Invalid modulation type',
                'valid_modulations': [m.name for m in ModulationType]
            }), 400
        
        # Modulate signal
        try:
            tx_signal = modulator.modulate(bits)
        except Exception as e:
            return jsonify({
                'error': 'Modulation failed',
                'details': str(e)
            }), 500
        
        # Initialize channel
        try:
            channel_type = ChannelType[params['channel']]
            channel = Channel(snr_db=params['snr_db'], channel_type=channel_type)
        except (KeyError, ValueError) as e:
            return jsonify({
                'error': 'Invalid channel type',
                'valid_channels': [c.name for c in ChannelType]
            }), 400
        
        # Pass through channel
        try:
            rx_signal, noise = channel.add_noise(tx_signal)
        except Exception as e:
            return jsonify({
                'error': 'Channel simulation failed',
                'details': str(e)
            }), 500
        
        # Calculate metrics
        try:
            # Initialize metrics with basic information
            metrics = {
                'snr_db': params['snr_db'],
                'ber': 0.0,  # Placeholder - would be calculated from demodulated bits
                'modulation': params['modulation'],
                'channel': params['channel']
            }
            
            # Generate BER vs SNR data
            snr_range = np.linspace(0, 20, 21)  # SNR from 0 to 20 dB
            theoretical_ber = []
            simulated_ber = []
            
            # Calculate theoretical BER for each SNR
            for snr in snr_range:
                ber = calculate_theoretical_ber(
                    params['modulation'],
                    params['channel'],
                    snr
                )
                theoretical_ber.append(ber)
                
                # For demonstration, we'll use a simple model for simulated BER
                # In a real implementation, you would run the simulation at each SNR
                if snr <= params['snr_db']:
                    # Simple model: simulated BER is slightly worse than theoretical
                    simulated_ber.append(ber * 1.5)
                else:
                    # For higher SNRs, use the same ratio as at the current SNR
                    simulated_ber.append(ber * (metrics.get('ber', 0) / theoretical_ber[-1]) if theoretical_ber[-1] > 0 else 0)
            
            # Add to metrics
            metrics.update({
                'theoretical_ber': theoretical_ber,
                'simulated_ber': simulated_ber,
                'snr_range': snr_range.tolist()
            })
            
        except Exception as e:
            app.logger.error(f"Error calculating metrics: {str(e)}\n{traceback.format_exc()}")
            metrics = {
                'error': 'Error calculating metrics',
                'details': str(e)
            }
        
        # Generate plots
        try:
            plots = generate_plots(tx_signal, rx_signal, modulator, params, metrics)
        except Exception as e:
            app.logger.error(f"Error generating plots: {str(e)}\n{traceback.format_exc()}")
            plots = {
                'error': 'Error generating plots',
                'details': str(e)
            }
        
        # Prepare response data
        response = {
            'success': True,
            'parameters': {
                'modulation': params['modulation'],
                'channel': params['channel'],
                'coding': params['coding'],
                'snr_db': params['snr_db'],
                'num_bits': len(bits),
                'use_random': params['use_random'],
                'message_length': len(message) if message else 0
            },
            'metrics': metrics,
            'plots': plots,
            'timestamp': datetime.utcnow().isoformat()
        }
        
        # Add to simulation history
        simulation_history.append({
            'timestamp': datetime.utcnow().isoformat(),
            'parameters': response['parameters'],
            'metrics': metrics
        })
        
        # Keep only the most recent simulations
        while len(simulation_history) > MAX_HISTORY_ITEMS:
            simulation_history.pop(0)
        
        return jsonify(response)
        
    except Exception as e:
        app.logger.error(f"Simulation error: {str(e)}\n{traceback.format_exc()}")
        return jsonify({
            'error': 'Internal server error',
            'details': str(e)
        }), 500

def generate_plots(tx_signal, rx_signal, modulator, params, metrics=None):
    """Generate base64 encoded plots for the web interface
    
    Args:
        tx_signal: Transmitted signal
        rx_signal: Received signal
        modulator: Modulator instance
        params: Dictionary of simulation parameters
        metrics: Optional dictionary of calculated metrics
        
    Returns:
        Dictionary containing base64 encoded plots
    """
    if metrics is None:
        metrics = {}
        
    plots = {}
    
    try:
        # Time domain plot - limit to first 100 points for better visualization
        fig = Figure(figsize=(8, 4))
        ax = fig.subplots()
        
        # Ensure we have enough points to plot
        plot_length = min(100, len(tx_signal), len(rx_signal))
        if plot_length == 0:
            return plots  # Not enough points to plot
            
        # Limit number of points for better performance
        max_points = 1000
        step = max(1, len(tx_signal) // max_points)
        t = np.arange(0, len(tx_signal[:plot_length]), step)
        
        # Plot real part of the signal
        ax.plot(t, np.real(tx_signal[::step][:len(t)]), 'b-', alpha=0.7, label='Transmitted (Real)')
        ax.plot(t, np.real(rx_signal[::step][:len(t)]), 'r-', alpha=0.5, label='Received (Real)')
        
        # Add title and labels
        ax.set_title(f"{params.get('modulation', 'Unknown')} - Time Domain (First {len(t)} samples)", fontsize=12)
        ax.set_xlabel('Sample Index', fontsize=10)
        ax.set_ylabel('Amplitude', fontsize=10)
        
        # Add grid and legend
        ax.grid(True, linestyle='--', alpha=0.7)
        ax.legend(fontsize=9)
        
        # Add SNR and other info if available
        info_text = f"SNR: {params.get('snr_db', 0):.1f} dB"
        if 'ber' in metrics:
            info_text += f"\nBER: {metrics['ber']:.2e}"
        
        ax.text(0.98, 0.98, info_text,
                transform=ax.transAxes, fontsize=9,
                verticalalignment='top', horizontalalignment='right',
                bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
        
        plt.tight_layout()
        plots['time_domain'] = fig_to_base64(fig)
        plt.close(fig)
        
        # 2. Constellation Diagram
        fig, ax = plt.subplots(figsize=(8, 8))
        
        # Subsample received signal for better visualization
        step = max(1, len(rx_signal) // 5000)  # Limit to 5000 points
        rx_subsampled = rx_signal[::step]
        
        # Plot received symbols
        ax.plot(np.real(rx_subsampled), np.imag(rx_subsampled), 'b.', 
                alpha=0.3, markersize=3, label='Received Symbols')
        
        # Plot ideal constellation points
        try:
            ideal_points = modulator.get_constellation_points()
            if ideal_points is not None and len(ideal_points) > 0:
                ax.plot(np.real(ideal_points), np.imag(ideal_points), 'ro', 
                        markersize=8, markerfacecolor='none', markeredgewidth=2,
                        label='Ideal Constellation')
        except Exception as e:
            app.logger.warning(f"Could not plot ideal constellation: {str(e)}")
        
        # Add title and labels
        ax.set_title(f"{params.get('modulation', 'Unknown')} - Constellation Diagram", fontsize=12)
        ax.set_xlabel('In-phase Component', fontsize=10)
        ax.set_ylabel('Quadrature Component', fontsize=10)
        
        # Add grid and legend
        ax.grid(True, linestyle='--', alpha=0.7)
        ax.legend(fontsize=9)
        
        # Ensure equal aspect ratio
        ax.axis('equal')
        
        # Add EVM if available
        if 'evm' in metrics:
            ax.text(0.98, 0.02, f"EVM: {metrics['evm']*100:.2f}%",
                    transform=ax.transAxes, fontsize=9,
                    verticalalignment='bottom', horizontalalignment='right',
                    bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
        
        plt.tight_layout()
        plots['constellation'] = fig_to_base64(fig)
        plt.close(fig)
        
        # 3. BER vs SNR Plot (theoretical and simulated)
        if all(key in metrics for key in ['theoretical_ber', 'snr_range', 'simulated_ber']):
            fig, ax = plt.subplots(figsize=(10, 6))
            
            # Plot theoretical BER
            ax.semilogy(metrics['snr_range'], metrics['theoretical_ber'], 
                       'r-', linewidth=2, label='Theoretical BER')
            
            # Plot simulated BER if available
            if metrics['simulated_ber'] is not None:
                ax.semilogy(metrics['snr_range'], metrics['simulated_ber'], 
                           'bo-', markersize=6, label='Simulated BER')
            
            # Highlight current SNR point
            current_snr = params.get('snr_db', 0)
            if 'ber' in metrics:
                ax.semilogy([current_snr], [metrics['ber']], 'go', 
                           markersize=10, markerfacecolor='none', markeredgewidth=2,
                           label=f'Current (SNR={current_snr} dB)')
            
            # Add title and labels
            ax.set_title(f"BER vs SNR - {params.get('modulation', 'Unknown')} in {params.get('channel', 'Unknown')} Channel", fontsize=12)
            ax.set_xlabel('SNR (dB)', fontsize=10)
            ax.set_ylabel('Bit Error Rate (BER)', fontsize=10)
            
            # Add grid and legend
            ax.grid(True, which="both", ls="--", alpha=0.7)
            ax.legend(fontsize=9)
            
            # Add current BER value
            if 'ber' in metrics:
                ax.text(0.02, 0.98, f"BER: {metrics['ber']:.2e}",
                        transform=ax.transAxes, fontsize=10,
                        verticalalignment='top',
                        bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
            
            plt.tight_layout()
            plots['ber_vs_snr'] = fig_to_base64(fig)
            plt.close(fig)
        
        # 4. Eye Diagram (for certain modulations)
        if params.get('modulation') in ['BPSK', 'QPSK']:
            try:
                eye_diagram = generate_eye_diagram(rx_signal, params['modulation'])
                if eye_diagram:
                    plots['eye_diagram'] = eye_diagram
            except Exception as e:
                app.logger.warning(f"Could not generate eye diagram: {str(e)}")
        
        return plots
        
    except Exception as e:
        app.logger.error(f"Error in generate_plots: {str(e)}\n{traceback.format_exc()}")
        # Return empty plots dict on error
        return {}

def generate_eye_diagram(signal: np.ndarray, modulation: str) -> Optional[str]:
    """Generate an eye diagram for the given signal."""
    try:
        # For simplicity, we'll create a basic eye diagram for BPSK/QPSK
        samples_per_symbol = 8  # Example value, adjust based on your system
        num_symbols = len(signal) // samples_per_symbol
        
        if num_symbols < 2:
            return None
            
        # Reshape to have one row per symbol period
        eye_data = signal[:num_symbols * samples_per_symbol].reshape(-1, samples_per_symbol)
        
        # Create time axis for one symbol period
        t = np.linspace(0, 2, samples_per_symbol, endpoint=False)
        
        fig, ax = plt.subplots(figsize=(10, 6))
        
        # Plot multiple symbol periods to create the eye diagram
        for i in range(min(100, len(eye_data))):  # Limit number of traces for performance
            ax.plot(t, np.real(eye_data[i]), 'b-', alpha=0.1)
        
        # Add title and labels
        ax.set_title(f"{modulation} - Eye Diagram", fontsize=12)
        ax.set_xlabel('Time (symbol periods)', fontsize=10)
        ax.set_ylabel('Amplitude', fontsize=10)
        ax.grid(True, linestyle='--', alpha=0.7)
        
        # Add vertical lines at symbol boundaries
        for i in range(0, 3):
            ax.axvline(x=i, color='r', linestyle='--', alpha=0.5)
        
        plt.tight_layout()
        
        # Convert to base64
        img = io.BytesIO()
        plt.savefig(img, format='png')
        plt.close(fig)
        img.seek(0)
        return base64.b64encode(img.getvalue()).decode('utf-8')
        
    except Exception as e:
        app.logger.warning(f"Error generating eye diagram: {str(e)}")
        return None

def fig_to_base64(fig: Figure) -> str:
    """
    Convert a matplotlib figure to a base64 encoded PNG string.
    
    Args:
        fig: Matplotlib figure to convert
        
    Returns:
        Base64-encoded PNG image as a string
    """
    try:
        buf = io.BytesIO()
        fig.savefig(buf, format='png', bbox_inches='tight', dpi=100)
        plt.close(fig)  # Close the figure to free memory
        buf.seek(0)
        return base64.b64encode(buf.read()).decode('utf-8')
    except Exception as e:
        app.logger.error(f"Error converting figure to base64: {str(e)}")
        return ""

def calculate_evm(tx_signal: np.ndarray, rx_signal: np.ndarray) -> float:
    """
    Calculate the Error Vector Magnitude (EVM) between transmitted and received signals.
    
    Args:
        tx_signal: Transmitted signal (complex)
        rx_signal: Received signal (complex)
        
    Returns:
        EVM as a fraction (0 to 1)
    """
    try:
        # Ensure signals have the same length
        min_len = min(len(tx_signal), len(rx_signal))
        if min_len == 0:
            return 1.0  # Maximum error if no signal
            
        tx = tx_signal[:min_len]
        rx = rx_signal[:min_len]
        
        # Calculate error vector
        error = tx - rx
        
        # Calculate EVM as RMS error divided by RMS of the reference signal
        evm_rms = np.sqrt(np.mean(np.abs(error) ** 2))
        ref_rms = np.sqrt(np.mean(np.abs(tx) ** 2))
        
        # Avoid division by zero
        if ref_rms == 0:
            return 1.0
            
        return float(evm_rms / ref_rms)
        
    except Exception as e:
        app.logger.error(f"Error calculating EVM: {str(e)}")
        return 1.0  # Return maximum error on failure

def calculate_theoretical_ber(modulation: str, channel: str, snr_db: float) -> float:
    """
    Calculate theoretical bit error rate (BER) for given modulation and channel.
    
    Args:
        modulation: Modulation type ('BPSK', 'QPSK', '16-QAM')
        channel: Channel type ('AWGN', 'Rayleigh')
        snr_db: Signal-to-noise ratio in dB
        
    Returns:
        Theoretical BER
    """
    try:
        # Convert SNR from dB to linear scale
        snr_linear = 10 ** (snr_db / 10.0)
        
        # Calculate theoretical BER based on modulation and channel
        if modulation == 'BPSK':
            if channel == 'AWGN':
                # BER for BPSK in AWGN: Q(sqrt(2*Eb/N0))
                return 0.5 * erfc(np.sqrt(snr_linear))
            else:  # Rayleigh
                # BER for BPSK in Rayleigh fading: 0.5*(1-sqrt(SNR/(1+SNR)))
                return 0.5 * (1 - np.sqrt(snr_linear / (1 + snr_linear)))
                
        elif modulation == 'QPSK':
            # For QPSK, the BER is similar to BPSK in terms of Eb/N0
            if channel == 'AWGN':
                return erfc(np.sqrt(snr_linear)) * (1 - 0.5 * erfc(np.sqrt(snr_linear)))
            else:  # Rayleigh
                # Approximate BER for QPSK in Rayleigh fading
                return 0.5 * (1 - np.sqrt(snr_linear / (2 + snr_linear)))
                
        elif modulation == '16-QAM':
            # For 16-QAM, the exact expression is more complex
            if channel == 'AWGN':
                # Approximate BER for 16-QAM in AWGN
                return (3/8) * erfc(np.sqrt(0.4 * snr_linear))
            else:  # Rayleigh
                # Approximate BER for 16-QAM in Rayleigh fading
                return 0.375 * (1 - np.sqrt(0.8 * snr_linear / (1 + 0.8 * snr_linear)))
                
        else:
            # Default to BPSK if modulation is not recognized
            return 0.5 * erfc(np.sqrt(snr_linear))
            
    except Exception as e:
        app.logger.error(f"Error calculating theoretical BER: {str(e)}")
        # Return a high BER value to indicate an error
        return 1.0

def erfc(x: float) -> float:
    """
    Complementary error function.
    
    Args:
        x: Input value
        
    Returns:
        Value of the complementary error function at x
    """
    return 0.5 * (2 - math.erfc(x / np.sqrt(2)))

# Add error handlers
@app.errorhandler(404)
def not_found_error(error):
    return render_template('error.html', 
                         error_code=404,
                         error_message='Page not found',
                         title='404 - Page Not Found'), 404

@app.errorhandler(500)
def internal_error(error):
    app.logger.error(f"Internal server error: {str(error)}\n{traceback.format_exc()}")
    return render_template('error.html',
                         error_code=500,
                         error_message='Internal server error',
                         title='500 - Internal Server Error'), 500

# Serve static files
@app.route('/static/<path:filename>')
def serve_static(filename):
    return send_from_directory('static', filename)

def generate_ber_plot(modulation: str, snr: float, ber: float) -> str:
    """
    Generate a BER vs SNR plot with theoretical curve and simulated point.
    
    Args:
        modulation: Modulation type ('BPSK', 'QPSK', '16-QAM')
        snr: Signal-to-noise ratio in dB
        ber: Bit Error Rate from simulation
        
    Returns:
        Base64 encoded image of the plot
    """
    try:
        # Generate SNR range for theoretical curve
        snr_range = np.linspace(0, 20, 100)
        
        # Calculate theoretical BER based on modulation
        if modulation.upper() == 'BPSK':
            theoretical_ber = 0.5 * scipy.special.erfc(np.sqrt(10 ** (snr_range/10)))
        elif modulation.upper() == 'QPSK':
            theoretical_ber = 0.5 * scipy.special.erfc(np.sqrt(10 ** (snr_range/10)))
        else:  # 16-QAM
            theoretical_ber = 3/8 * scipy.special.erfc(np.sqrt(0.4 * 10 ** (snr_range/10)))
        
        # Create figure with white background
        plt.figure(figsize=(10, 6), facecolor='white')
        
        # Plot theoretical curve in red with thicker line
        plt.semilogy(snr_range, theoretical_ber, 'r-', linewidth=2.5, 
                    label=f'Theoretical {modulation}')
        
        # Plot simulated point with a black circle marker
        plt.semilogy(snr, ber, 'ko', markersize=8, 
                    markerfacecolor='none',  # Hollow circle
                    markeredgewidth=1.5,
                    label=f'Simulated (SNR={snr:.1f}dB, BER={ber:.2e})')
        
        # Add a small horizontal line at the simulated point
        if snr > 0:
            plt.axhline(y=ber, color='black', linestyle=':', alpha=0.3, xmax=(snr/20))
        
        # Set plot limits and labels
        plt.xlim(0, 20)
        plt.ylim(1e-6, 1)  # Standard BER range
        plt.title('Bit Error Rate vs SNR', fontsize=14, pad=15)
        plt.xlabel('SNR (dB)', fontsize=12, labelpad=10)
        plt.ylabel('Bit Error Rate', fontsize=12, labelpad=10)
        
        # Customize grid and ticks
        plt.grid(True, which='major', linestyle='-', color='#DDDDDD')
        plt.grid(True, which='minor', linestyle=':', color='#EEEEEE')
        
        # Set y-axis to show standard BER values
        plt.gca().yaxis.set_major_formatter(matplotlib.ticker.ScalarFormatter())
        plt.yticks([1e-6, 1e-5, 1e-4, 1e-3, 1e-2, 1e-1, 1])
        
        # Add legend and customize plot appearance
        plt.legend(loc='upper right', frameon=True, framealpha=0.9)
        plt.gca().spines['top'].set_visible(False)
        plt.gca().spines['right'].set_visible(False)
        plt.tight_layout()
        
        # Save plot to bytes
        img = BytesIO()
        plt.savefig(img, format='png', bbox_inches='tight', dpi=100)
        img.seek(0)
        plt.close()
        
        return base64.b64encode(img.getvalue()).decode('utf-8')
        
    except Exception as e:
        app.logger.error(f"Error generating BER plot: {str(e)}")
        return None

@app.route('/ber_simulation')
def ber_simulation():
    """Generate and display BER vs SNR plots for different modulations."""
    try:
        # Get parameters from request or use defaults
        snr = float(request.args.get('snr', 10.0))  # Default SNR of 10 dB if not provided
        
        # Get the modulation type from the request or use all
        mod_type = request.args.get('modulation')
        
        # If no specific modulation is requested, show all
        if not mod_type:
            # Import the BER simulation functions
            from ber_simulation import (
                SNR_dB, MODULATION_TYPES,
                simulate_ber, plot_ber
            )
            
            # Run simulation for each modulation type
            plot_data = {}
            for mod in MODULATION_TYPES:
                try:
                    # Run simulation
                    ber_sim, ber_theo = simulate_ber(mod)
                    
                    # Generate the plot
                    plt.figure(figsize=(10, 6))
                    plt.semilogy(SNR_dB, ber_sim, 'bo-', linewidth=2, label='Simulated')
                    plt.semilogy(SNR_dB, ber_theo, 'r--', linewidth=2, label='Theoretical')
                    
                    plt.title(f'BER vs SNR for {mod}', fontsize=14)
                    plt.xlabel('SNR (dB)', fontsize=12)
                    plt.ylabel('Bit Error Rate (BER)', fontsize=12)
                    plt.grid(True, which="both", ls="--")
                    plt.legend(fontsize=10)
                    plt.xticks(SNR_dB)
                    plt.ylim(1e-6, 1)
                    
                    # Save plot to bytes
                    img = BytesIO()
                    plt.savefig(img, format='png', bbox_inches='tight', dpi=100)
                    img.seek(0)
                    plt.close()
                    
                    # Add to plot data
                    plot_data[mod] = base64.b64encode(img.getvalue()).decode('utf-8')
                    
                except Exception as e:
                    app.logger.error(f"Error generating {mod} plot: {str(e)}")
                    continue
            
            return render_template('ber_simulation.html', 
                                plot_data=plot_data,
                                snr=snr)
        else:
            # Single modulation type requested
            ber = float(request.args.get('ber', 0.0))  # Default to 0 if not provided
            plot_data = generate_ber_plot(mod_type, snr, ber)
            
            if plot_data:
                return render_template('ber_simulation.html', 
                                    plot_data={mod_type: plot_data},
                                    snr=snr,
                                    ber=ber)
            else:
                return render_template('error.html', 
                                    error_message='Failed to generate BER plot',
                                    title='Error'), 500
    
    except Exception as e:
        app.logger.error(f"Error in ber_simulation: {str(e)}\n{traceback.format_exc()}")
        return render_template('error.html',
                            error_message='An error occurred while generating BER plots',
                            title='Error'), 500

if __name__ == '__main__':
    # Create necessary directories
    os.makedirs('static', exist_ok=True)
    
    # Print startup message
    print("\n" + "="*60)
    print("Digital Communication System Simulator")
    print("="*60)
    print(f"Running on http://127.0.0.1:5000/")
    print("Press Ctrl+C to stop\n")
    
    # Run the application
    app.run(host='0.0.0.0', port=5000, debug=True)
