import numpy as np
from enum import Enum

class ModulationType(Enum):
    BPSK = 1
    QPSK = 2
    QAM16 = 3

class Modulator:
    def __init__(self, sps=8, fs=1.0):
        """
        Initialize the modulator
        :param sps: Samples per symbol
        :param fs: Sampling frequency
        """
        self.sps = sps
        self.fs = fs
        self.modulation_type = ModulationType.BPSK
        
    def generate_symbols(self, bits):
        """Convert bits to symbols based on modulation type"""
        if self.modulation_type == ModulationType.BPSK:
            return 1 - 2 * bits  # 0 -> +1, 1 -> -1
            
        elif self.modulation_type == ModulationType.QPSK:
            # Reshape bits into pairs
            reshaped_bits = bits.reshape(-1, 2)
            # Gray coding: 00 -> 1+j, 01 -> -1+j, 11 -> -1-j, 10 -> 1-j
            symbols = (1 - 2 * reshaped_bits[:, 0]) + 1j * (1 - 2 * reshaped_bits[:, 1])
            return symbols / np.sqrt(2)  # Normalize power
            
        elif self.modulation_type == ModulationType.QAM16:
            # Reshape into groups of 4 bits
            reshaped_bits = bits.reshape(-1, 4)
            # Gray coding for 16-QAM
            re = 3 - 2 * reshaped_bits[:, 0] - 4 * reshaped_bits[:, 1]
            im = 3 - 2 * reshaped_bits[:, 2] - 4 * reshaped_bits[:, 3]
            return (re + 1j * im) / np.sqrt(10)  # Normalize power
    
    def modulate(self, bits, fc=0.25):
        """
        Modulate bits into baseband signal
        :param bits: Input bit array (0s and 1s)
        :param fc: Carrier frequency (normalized)
        :return: Modulated signal
        """
        # Generate symbols
        symbols = self.generate_symbols(bits)
        
        # Upsample
        upsampled = np.zeros(len(symbols) * self.sps, dtype=np.complex128)
        upsampled[::self.sps] = symbols
        
        # Apply RRC filter (implement if needed)
        # For now, just return the upsampled signal
        return upsampled
    
    def get_constellation_points(self):
        """Return the constellation points for the current modulation"""
        if self.modulation_type == ModulationType.BPSK:
            return np.array([-1, 1])
        elif self.modulation_type == ModulationType.QPSK:
            return np.array([1+1j, -1+1j, -1-1j, 1-1j]) / np.sqrt(2)
        elif self.modulation_type == ModulationType.QAM16:
            points = []
            for i in [-3, -1, 1, 3]:
                for q in [-3, -1, 1, 3]:
                    points.append(i + 1j*q)
            return np.array(points) / np.sqrt(10)
        return np.array([])
    
    def get_modulation_name(self):
        """Return the name of the current modulation scheme"""
        return self.modulation_type.name
