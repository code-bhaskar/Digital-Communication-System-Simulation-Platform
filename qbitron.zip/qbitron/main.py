#!/usr/bin/env python3
"""
Digital Communication System Simulator
------------------------------------
A comprehensive simulation platform for digital communication systems.
Supports various modulation schemes, channel models, and visualization tools.
"""
import sys
import os
import logging
from PyQt6.QtWidgets import QApplication

# Add the current directory to the Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler('communication_simulator.log')
    ]
)
logger = logging.getLogger(__name__)

def check_dependencies():
    """Check if all required dependencies are installed"""
    required = ['numpy', 'scipy', 'matplotlib', 'PyQt6', 'pyqtgraph']
    missing = []
    
    for package in required:
        try:
            __import__(package)
        except ImportError:
            missing.append(package)
    
    if missing:
        logger.error(f"Missing required packages: {', '.join(missing)}")
        print(f"\nError: The following required packages are missing:\n{', '.join(missing)}\n")
        print("Please install them using:")
        print("pip install -r requirements.txt")
        return False
    return True

def main():
    """Main entry point for the application"""
    # Check dependencies first
    if not check_dependencies():
        return 1
    
    try:
        from gui import CommunicationSystemGUI
        
        app = QApplication(sys.argv)
        app.setStyle('Fusion')  # Modern look and feel
        
        # Set application information
        app.setApplicationName("Digital Communication System Simulator")
        app.setApplicationVersion("1.0.0")
        
        logger.info("Starting Digital Communication System Simulator")
        
        window = CommunicationSystemGUI()
        window.show()
        
        return app.exec()
    
    except Exception as e:
        logger.exception("An error occurred while running the application")
        print(f"\nA critical error occurred: {str(e)}")
        print("Please check the log file for more details.")
        return 1

if __name__ == '__main__':
    sys.exit(main())
