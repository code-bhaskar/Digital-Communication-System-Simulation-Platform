import numpy as np
import matplotlib.pyplot as plt
from scipy.special import erfc
import warnings
warnings.filterwarnings('ignore')  # Suppress complex number warnings

# Simulation parameters
NUM_BITS = 100000  # Number of bits to simulate
SNR_dB = np.arange(0, 21, 2)  # SNR range from 0 to 20 dB
MODULATION_TYPES = ['BPSK', 'QPSK', '16-QAM']

# Bit generation
def generate_bits(num_bits):
    """Generate random bits (0s and 1s)."""
    return np.random.randint(0, 2, num_bits)

# Modulation functions
def modulate_bpsk(bits):
    """Modulate bits using BPSK: 0 -> -1, 1 -> +1"""
    return 2 * bits - 1

def modulate_qpsk(bits):
    """Modulate bits using QPSK."""
    # Reshape bits into symbol pairs
    symbols = bits.reshape(-1, 2)
    # Map to QPSK constellation points
    return (2 * symbols[:, 0] - 1) + 1j * (2 * symbols[:, 1] - 1)

def modulate_16qam(bits):
    """Modulate bits using 16-QAM."""
    # Reshape into groups of 4 bits
    symbols = bits.reshape(-1, 4)
    # Map to 16-QAM constellation (normalized to unit energy)
    mapping = {
        '0000': -3-3j, '0001': -3-1j, '0010': -3+3j, '0011': -3+1j,
        '0100': -1-3j, '0101': -1-1j, '0110': -1+3j, '0111': -1+1j,
        '1000':  3-3j, '1001':  3-1j, '1010':  3+3j, '1011':  3+1j,
        '1100':  1-3j, '1101':  1-1j, '1110':  1+3j, '1111':  1+1j
    }
    # Normalization factor for unit average energy
    norm_factor = np.sqrt(10)
    
    # Convert each 4-bit group to symbol
    symbols_str = [''.join(map(str, map(int, sym))) for sym in symbols]
    return np.array([mapping[s] for s in symbols_str]) / norm_factor

# AWGN Channel
def add_awgn(signal, snr_db):
    """Add AWGN to the signal for given SNR in dB."""
    # Calculate signal power and convert to linear scale
    if np.iscomplexobj(signal):
        signal_power = np.mean(np.abs(signal) ** 2)
    else:
        signal_power = np.mean(signal ** 2)
    
    # Convert SNR from dB to linear scale
    snr_linear = 10 ** (snr_db / 10.0)
    
    # Calculate noise power
    noise_power = signal_power / snr_linear
    
    # Generate complex noise
    if np.iscomplexobj(signal):
        noise = np.sqrt(noise_power/2) * (np.random.randn(*signal.shape) + 1j * np.random.randn(*signal.shape))
    else:
        noise = np.sqrt(noise_power) * np.random.randn(*signal.shape)
    
    return signal + noise

# Demodulation functions
def demodulate_bpsk(received):
    """Demodulate BPSK signal."""
    return (np.real(received) > 0).astype(int)

def demodulate_qpsk(received):
    """Demodulate QPSK signal."""
    # Make decisions on I and Q components
    i_bits = (np.real(received) > 0).astype(int)
    q_bits = (np.imag(received) > 0).astype(int)
    
    # Interleave I and Q bits
    return np.column_stack((i_bits, q_bits)).flatten()

def demodulate_16qam(received):
    """Demodulate 16-QAM signal."""
    # Normalization factor
    norm_factor = np.sqrt(10)
    
    # Scale back the received signal
    scaled = received * norm_factor
    
    # Decision boundaries
    boundaries = [-2, 0, 2]
    
    # Demodulate I and Q components
    i_bits = np.digitize(np.real(scaled), boundaries)
    q_bits = np.digitize(np.imag(scaled), boundaries)
    
    # Convert to bits (2 bits per dimension)
    def bits_from_level(level):
        return [(level >> (1 - i)) & 1 for i in range(2)]
    
    # Convert each symbol to 4 bits (2 for I, 2 for Q)
    bits = []
    for i, q in zip(i_bits, q_bits):
        i_bits = bits_from_level(i)
        q_bits = bits_from_level(q)
        bits.extend(i_bits + q_bits)
    
    return np.array(bits)

# Theoretical BER calculations
def theoretical_ber_bpsk(snr_db):
    """Calculate theoretical BER for BPSK."""
    snr_linear = 10 ** (snr_db / 10.0)
    return 0.5 * erfc(np.sqrt(snr_linear))

def theoretical_ber_qpsk(snr_db):
    """Calculate theoretical BER for QPSK."""
    # Same as BPSK in terms of Eb/N0
    return theoretical_ber_bpsk(snr_db)

def theoretical_ber_16qam(snr_db):
    """Calculate theoretical BER for 16-QAM."""
    snr_linear = 10 ** (snr_db / 10.0)
    return 0.75 * 0.5 * erfc(np.sqrt(0.4 * snr_linear))

# Main simulation function
def simulate_ber(modulation_type, num_bits=NUM_BITS):
    """Run BER simulation for given modulation type."""
    print(f"\nSimulating {modulation_type}...")
    print("SNR (dB)\tSim BER\t\tTheo BER")
    print("-" * 40)
    
    # Initialize arrays to store results
    ber_sim = np.zeros_like(SNR_dB, dtype=float)
    ber_theo = np.zeros_like(SNR_dB, dtype=float)
    
    # Generate bits
    bits = generate_bits(num_bits)
    
    # Select modulation/demodulation functions
    if modulation_type == 'BPSK':
        modulate = modulate_bpsk
        demodulate = demodulate_bpsk
        theoretical_ber = theoretical_ber_bpsk
        # Adjust number of bits to avoid reshaping issues
        num_symbols = len(bits)
    elif modulation_type == 'QPSK':
        modulate = modulate_qpsk
        demodulate = demodulate_qpsk
        theoretical_ber = theoretical_ber_qpsk
        # Ensure number of bits is even for QPSK
        num_symbols = (len(bits) // 2) * 2
        bits = bits[:num_symbols]
    elif modulation_type == '16-QAM':
        modulate = modulate_16qam
        demodulate = demodulate_16qam
        theoretical_ber = theoretical_ber_16qam
        # Ensure number of bits is multiple of 4 for 16-QAM
        num_symbols = (len(bits) // 4) * 4
        bits = bits[:num_symbols]
    else:
        raise ValueError(f"Unsupported modulation type: {modulation_type}")
    
    # Modulate bits
    tx_symbols = modulate(bits)
    
    # Run simulation for each SNR value
    for i, snr in enumerate(SNR_dB):
        # Add AWGN
        rx_symbols = add_awgn(tx_symbols, snr)
        
        # Demodulate
        rx_bits = demodulate(rx_symbols)
        
        # Calculate BER (ensure lengths match)
        min_len = min(len(bits), len(rx_bits))
        bit_errors = np.sum(bits[:min_len] != rx_bits[:min_len])
        ber_sim[i] = bit_errors / min_len
        
        # Calculate theoretical BER
        ber_theo[i] = theoretical_ber(snr)
        
        # Print results
        print(f"{snr:3d} dB\t\t{ber_sim[i]:.2e}\t{ber_theo[i]:.2e}")
    
    return ber_sim, ber_theo

# Plot results
def plot_ber(modulation_type, ber_sim, ber_theo):
    """Plot BER vs SNR for simulation and theoretical results."""
    plt.figure(figsize=(10, 6))
    plt.semilogy(SNR_dB, ber_sim, 'bo-', linewidth=2, label='Simulated')
    plt.semilogy(SNR_dB, ber_theo, 'r--', linewidth=2, label='Theoretical')
    
    plt.title(f'BER vs SNR for {modulation_type}', fontsize=14)
    plt.xlabel('SNR (dB)', fontsize=12)
    plt.ylabel('Bit Error Rate (BER)', fontsize=12)
    plt.grid(True, which="both", ls="--")
    plt.legend(fontsize=10)
    plt.xticks(SNR_dB)
    plt.ylim(1e-6, 1)
    
    # Save the plot
    plt.savefig(f'ber_vs_snr_{modulation_type.lower()}.png', dpi=300, bbox_inches='tight')
    plt.close()

# Main function
def main():
    # Run simulation for each modulation type
    for mod_type in MODULATION_TYPES:
        try:
            ber_sim, ber_theo = simulate_ber(mod_type)
            plot_ber(mod_type, ber_sim, ber_theo)
        except Exception as e:
            print(f"Error simulating {mod_type}: {str(e)}")
            continue
    
    print("\nSimulation complete! BER vs SNR plots have been saved as 'ber_vs_snr_<modulation>.png'")

if __name__ == "__main__":
    main()
