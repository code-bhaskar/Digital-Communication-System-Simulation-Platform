import numpy as np
from enum import Enum

class ChannelType(Enum):
    AWGN = 1
    RAYLEIGH = 2

class Channel:
    def __init__(self, snr_db=10, channel_type=ChannelType.AWGN):
        """
        Initialize the channel
        :param snr_db: Signal-to-noise ratio in dB
        :param channel_type: Type of channel (AWGN or Rayleigh)
        """
        self.snr_db = snr_db
        self.channel_type = channel_type
        self.fading_coeff = 1.0
        
    def set_snr(self, snr_db):
        """Set the SNR in dB"""
        self.snr_db = snr_db
        
    def add_noise(self, signal):
        """
        Add noise to the signal based on the channel type and SNR
        :param signal: Input signal (can be complex)
        :return: Noisy signal
        """
        # Calculate signal power
        signal_power = np.mean(np.abs(signal) ** 2)
        
        # Convert SNR from dB to linear scale
        snr_linear = 10 ** (self.snr_db / 10.0)
        
        # Calculate noise power
        noise_power = signal_power / snr_linear
        
        # Generate complex noise
        noise = np.sqrt(noise_power / 2) * (np.random.randn(len(signal)) + 1j * np.random.randn(len(signal)))
        
        # Apply fading if needed
        if self.channel_type == ChannelType.RAYLEIGH:
            # Generate new fading coefficient for each call (block fading)
            self.fading_coeff = (np.random.randn() + 1j * np.random.randn()) / np.sqrt(2)
            signal = signal * self.fading_coeff
        
        # Add noise to signal
        noisy_signal = signal + noise
        
        return noisy_signal, noise
    
    def get_ber(self, tx_bits, rx_bits):
        """
        Calculate Bit Error Rate (BER)
        :param tx_bits: Transmitted bits
        :param rx_bits: Received bits
        :return: BER
        """
        if len(tx_bits) != len(rx_bits):
            raise ValueError("Input arrays must have the same length")
            
        errors = np.sum(tx_bits != rx_bits)
        return errors / len(tx_bits), errors
    
    def get_theoretical_ber(self, modulation, eb_n0_db):
        """
        Calculate theoretical BER for different modulations
        :param modulation: Modulation type (ModulationType)
        :param eb_n0_db: Eb/N0 in dB
        :return: Theoretical BER
        """
        eb_n0 = 10 ** (eb_n0_db / 10.0)
        
        if modulation == ModulationType.BPSK:
            return 0.5 * erfc(np.sqrt(eb_n0))
        elif modulation == ModulationType.QPSK:
            return 0.5 * erfc(np.sqrt(eb_n0))
        elif modulation == ModulationType.QAM16:
            return (3/8) * erfc(np.sqrt(0.4 * eb_n0))  # Approximation for 16-QAM
        return 0.0

def erfc(x):
    """Complementary error function"""
    return 2 * (1 - 0.5 * (1 + np.math.erf(x / np.sqrt(2))))
