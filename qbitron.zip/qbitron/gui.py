import sys
import numpy as np
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
                            QLabel, QComboBox, QSlider, QPushButton, QGroupBox, QFormLayout)
from PyQt6.QtCore import Qt, QTimer
import pyqtgraph as pg
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import matplotlib.pyplot as plt

from modulation import Modulator, ModulationType
from channel import Channel, ChannelType

class CommunicationSystemGUI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Digital Communication System Simulator")
        self.setGeometry(100, 100, 1200, 800)
        
        # Initialize components
        self.modulator = Modulator()
        self.channel = Channel()
        
        # Data storage
        self.tx_bits = None
        self.tx_signal = None
        self.rx_signal = None
        self.noise = None
        
        self.init_ui()
        
    def init_ui(self):
        """Initialize the user interface"""
        # Main widget and layout
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        layout = QHBoxLayout(main_widget)
        
        # Left panel for controls
        left_panel = QWidget()
        left_layout = QVBoxLayout(left_panel)
        left_layout.setAlignment(Qt.AlignmentFlag.AlignTop)
        
        # Add control panels
        left_layout.addWidget(self.create_modulation_panel())
        left_layout.addWidget(self.create_channel_panel())
        left_layout.addWidget(self.create_simulation_panel())
        
        # Right panel for plots
        right_panel = QWidget()
        right_layout = QVBoxLayout(right_panel)
        
        # Create matplotlib figure and canvas
        self.figure = Figure(figsize=(8, 10), dpi=100)
        self.canvas = FigureCanvas(self.figure)
        right_layout.addWidget(self.canvas)
        
        # Set up the plots
        self.setup_plots()
        
        # Add panels to main layout
        layout.addWidget(left_panel, stretch=1)
        layout.addWidget(right_panel, stretch=3)
        
        # Set initial simulation
        self.generate_bits()
        self.update_simulation()
        
    def create_modulation_panel(self):
        """Create modulation control panel"""
        group = QGroupBox("Modulation Settings")
        layout = QFormLayout()
        
        # Modulation type selection
        self.modulation_combo = QComboBox()
        self.modulation_combo.addItems([m.name for m in ModulationType])
        self.modulation_combo.currentTextChanged.connect(self.on_modulation_changed)
        layout.addRow("Modulation:", self.modulation_combo)
        
        # Symbol rate
        self.symbol_rate = QSlider(Qt.Orientation.Horizontal)
        self.symbol_rate.setRange(1, 10)
        self.symbol_rate.setValue(5)
        self.symbol_rate.valueChanged.connect(self.update_simulation)
        layout.addRow("Symbol Rate:", self.symbol_rate)
        
        group.setLayout(layout)
        return group
        
    def create_channel_panel(self):
        """Create channel control panel"""
        group = QGroupBox("Channel Settings")
        layout = QFormLayout()
        
        # Channel type selection
        self.channel_combo = QComboBox()
        self.channel_combo.addItems([c.name for c in ChannelType])
        self.channel_combo.currentTextChanged.connect(self.on_channel_changed)
        layout.addRow("Channel Type:", self.channel_combo)
        
        # SNR control
        self.snr_slider = QSlider(Qt.Orientation.Horizontal)
        self.snr_slider.setRange(-10, 30)
        self.snr_slider.setValue(10)
        self.snr_slider.valueChanged.connect(self.on_snr_changed)
        layout.addRow("SNR (dB):", self.snr_slider)
        
        group.setLayout(layout)
        return group
        
    def create_simulation_panel(self):
        """Create simulation control panel"""
        group = QGroupBox("Simulation Controls")
        layout = QVBoxLayout()
        
        # Buttons
        self.run_button = QPushButton("Run Simulation")
        self.run_button.clicked.connect(self.update_simulation)
        
        self.reset_button = QPushButton("Reset")
        self.reset_button.clicked.connect(self.reset_simulation)
        
        # Status labels
        self.status_label = QLabel("Ready")
        self.ber_label = QLabel("BER: N/A")
        
        # Add widgets to layout
        layout.addWidget(self.run_button)
        layout.addWidget(self.reset_button)
        layout.addWidget(self.status_label)
        layout.addWidget(self.ber_label)
        layout.addStretch()
        
        group.setLayout(layout)
        return group
        
    def setup_plots(self):
        """Initialize the matplotlib plots"""
        self.figure.clear()
        
        # Create 3 subplots
        self.ax1 = self.figure.add_subplot(311)  # Time domain
        self.ax2 = self.figure.add_subplot(312)  # Constellation
        self.ax3 = self.figure.add_subplot(313)  # BER vs SNR
        
        # Set titles and labels
        self.ax1.set_title("Modulated Signal (Time Domain)")
        self.ax1.set_xlabel("Time")
        self.ax1.set_ylabel("Amplitude")
        
        self.ax2.set_title("Constellation Diagram")
        self.ax2.set_xlabel("In-phase")
        self.ax2.set_ylabel("Quadrature")
        self.ax2.grid(True)
        
        self.ax3.set_title("BER vs SNR")
        self.ax3.set_xlabel("SNR (dB)")
        self.ax3.set_ylabel("Bit Error Rate")
        self.ax3.set_yscale('log')
        self.ax3.grid(True)
        
        self.figure.tight_layout()
        self.canvas.draw()
        
    def generate_bits(self, num_bits=1000):
        """Generate random bits for transmission"""
        self.tx_bits = np.random.randint(0, 2, num_bits)
        
    def on_modulation_changed(self, text):
        """Handle modulation type change"""
        self.modulator.modulation_type = ModulationType[text]
        self.update_simulation()
        
    def on_channel_changed(self, text):
        """Handle channel type change"""
        self.channel.channel_type = ChannelType[text]
        self.update_simulation()
        
    def on_snr_changed(self, value):
        """Handle SNR slider change"""
        self.channel.set_snr(value)
        self.update_simulation()
        
    def update_simulation(self):
        """Update the simulation with current parameters"""
        try:
            # Modulate the signal
            self.tx_signal = self.modulator.modulate(self.tx_bits)
            
            # Pass through channel
            self.rx_signal, self.noise = self.channel.add_noise(self.tx_signal)
            
            # Update plots
            self.update_plots()
            self.status_label.setText("Simulation updated")
            
        except Exception as e:
            self.status_label.setText(f"Error: {str(e)}")
            
    def update_plots(self):
        """Update all plots with current data"""
        # Clear plots
        self.ax1.clear()
        self.ax2.clear()
        
        # Plot time domain
        t = np.arange(len(self.tx_signal))
        self.ax1.plot(t, np.real(self.tx_signal), 'b-', label='Transmitted')
        self.ax1.plot(t, np.real(self.rx_signal), 'r-', alpha=0.7, label='Received')
        self.ax1.legend()
        self.ax1.set_title(f"{self.modulator.get_modulation_name()} - Time Domain")
        
        # Plot constellation
        if len(self.rx_signal) > 0:
            # Downsample to avoid too many points
            step = max(1, len(self.rx_signal) // 1000)
            rx_subsampled = self.rx_signal[::step]
            self.ax2.plot(np.real(rx_subsampled), np.imag(rx_subsampled), 'b.', alpha=0.3)
            
            # Plot ideal constellation points
            ideal_points = self.modulator.get_constellation_points()
            self.ax2.plot(np.real(ideal_points), np.imag(ideal_points), 'ro', 
                         markersize=8, markerfacecolor='none', markeredgewidth=2)
            
            # Set equal aspect ratio
            self.ax2.axis('equal')
            self.ax2.grid(True)
            self.ax2.set_title(f"{self.modulator.get_modulation_name()} - Constellation")
        
        # Update BER plot (placeholder - would need actual detection/decoding)
        self.update_ber_plot()
        
        # Redraw canvas
        self.figure.tight_layout()
        self.canvas.draw()
        
    def update_ber_plot(self):
        """Update BER vs SNR plot"""
        self.ax3.clear()
        snr_db = np.linspace(-5, 20, 20)
        
        # Calculate theoretical BER for current modulation
        mod_type = self.modulator.modulation_type
        ber = [self.channel.get_theoretical_ber(mod_type, snr) for snr in snr_db]
        
        # Plot theoretical BER
        self.ax3.semilogy(snr_db, ber, 'b-', label='Theoretical')
        
        # Add current SNR point
        current_snr = self.channel.snr_db
        current_ber = self.channel.get_theoretical_ber(mod_type, current_snr)
        self.ax3.semilogy([current_snr], [current_ber], 'ro', label='Current')
        
        self.ax3.set_title(f"BER vs SNR - {mod_type.name}")
        self.ax3.set_xlabel("SNR (dB)")
        self.ax3.set_ylabel("Bit Error Rate")
        self.ax3.legend()
        self.ax3.grid(True, which="both", ls="-")
        
        # Update BER label
        self.ber_label.setText(f"Theoretical BER: {current_ber:.2e}")
        
    def reset_simulation(self):
        """Reset the simulation to default values"""
        self.modulation_combo.setCurrentIndex(0)
        self.channel_combo.setCurrentIndex(0)
        self.snr_slider.setValue(10)
        self.symbol_rate.setValue(5)
        self.generate_bits()
        self.update_simulation()
        self.status_label.setText("Simulation reset")

def main():
    app = QApplication(sys.argv)
    app.setStyle('Fusion')  # Modern look and feel
    
    # Set dark theme
    palette = app.palette()
    palette.setColor(palette.ColorRole.Window, Qt.GlobalColor.darkGray)
    palette.setColor(palette.ColorRole.WindowText, Qt.GlobalColor.white)
    app.setPalette(palette)
    
    window = CommunicationSystemGUI()
    window.show()
    sys.exit(app.exec())

if __name__ == '__main__':
    main()
