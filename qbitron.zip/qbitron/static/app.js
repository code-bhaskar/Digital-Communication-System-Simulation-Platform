// Global variables
let simulationResults = null;
let currentTab = 'home';
let isSimulationRunning = false;

// DOM Elements
const simulationForm = document.getElementById('simulationForm');
const runSimulationBtn = document.getElementById('runSimulation');
const resetBtn = document.getElementById('resetSimulation');
const tabs = document.querySelectorAll('.tab');
const tabContents = document.querySelectorAll('.tab-content');
const snrSlider = document.getElementById('snr');
const snrValue = document.getElementById('snrValue');
const numBitsInput = document.getElementById('numBits');
const useRandomCheckbox = document.getElementById('useRandom');
const messageInput = document.getElementById('message');
const theoryContent = document.getElementById('theoryContent');
const resultsContainer = document.getElementById('resultsContainer');
const timeDomainPlot = document.getElementById('timeDomainPlot');
const constellationPlot = document.getElementById('constellationPlot');
const berPlot = document.getElementById('berPlot');
const resultsInfo = document.getElementById('resultsInfo');

// Theory content for different modulation schemes
const theoryContentMap = {
    'BPSK': {
        title: 'Binary Phase-Shift Keying (BPSK)',
        content: `
            <h4>BPSK Theory</h4>
            <p>Binary Phase-Shift Keying (BPSK) is a digital modulation scheme that conveys data by changing (modulating) the phase of a reference signal (the carrier wave).</p>
            
            <h5>Key Characteristics:</h5>
            <ul>
                <li>Uses two phases separated by 180° (0° and 180° or π radians)</li>
                <li>Each symbol represents 1 bit (0 or 1)</li>
                <li>Most robust of all PSKs</li>
                <li>Lower data rate compared to higher-order PSK</li>
                <li>BER: $P_b = Q\left(\sqrt{\frac{2E_b}{N_0}}\right)$</li>
            </ul>
            
            <h5>Mathematical Representation:</h5>
            <p>For bit 0: $s_0(t) = A\cos(2\pi f_c t + \pi) = -A\cos(2\pi f_c t)$</p>
            <p>For bit 1: $s_1(t) = A\cos(2\pi f_c t)$</p>
        `
    },
    'QPSK': {
        title: 'Quadrature Phase-Shift Keying (QPSK)',
        content: `
            <h4>QPSK Theory</h4>
            <p>Quadrature Phase-Shift Keying (QPSK) is a digital modulation scheme that conveys data by changing (modulating) the phase of a reference signal (the carrier wave).</p>
            
            <h5>Key Characteristics:</h5>
            <ul>
                <li>Uses four phases (0°, 90°, 180°, 270° or π/4, 3π/4, 5π/4, 7π/4)</li>
                <li>Each symbol represents 2 bits (00, 01, 10, 11)</li>
                <li>Twice the bandwidth efficiency of BPSK</li>
                <li>BER: $P_b = Q\left(\sqrt{\frac{2E_b}{N_0}}\right)$ (same as BPSK in terms of energy per bit)</li>
            </ul>
            
            <h5>Mathematical Representation:</h5>
            <p>Symbols are represented as complex numbers:</p>
            <ul>
                <li>00: $\frac{1}{\sqrt{2}} + j\frac{1}{\sqrt{2}}$</li>
                <li>01: $-\frac{1}{\sqrt{2}} + j\frac{1}{\sqrt{2}}$</li>
                <li>11: $-\frac{1}{\sqrt{2}} - j\frac{1}{\sqrt{2}}$</li>
                <li>10: $\frac{1}{\sqrt{2}} - j\frac{1}{\sqrt{2}}$</li>
            </ul>
        `
    },
    '16-QAM': {
        title: '16-Quadrature Amplitude Modulation (16-QAM)',
        content: `
            <h4>16-QAM Theory</h4>
            <p>16-Quadrature Amplitude Modulation (16-QAM) is a digital modulation scheme that conveys data by changing both the amplitude and phase of a reference signal.</p>
            
            <h5>Key Characteristics:</h5>
            <ul>
                <li>Uses 16 different symbols (4 bits per symbol)</li>
                <li>Higher spectral efficiency than PSK</li>
                <li>More susceptible to noise and interference</li>
                <li>BER (approximate): $P_b \approx \frac{3}{4}Q\left(\sqrt{\frac{4E_b}{5N_0}}\right)$</li>
            </ul>
            
            <h5>Constellation Diagram:</h5>
            <p>16-QAM uses a 4×4 square grid of points in the I-Q plane, with equal spacing in both I and Q directions.</p>
            
            <h5>Advantages:</h5>
            <ul>
                <li>Higher data rate compared to PSK for the same bandwidth</li>
                <li>More efficient use of bandwidth</li>
            </ul>
            
            <h5>Disadvantages:</h5>
            <ul>
                <li>More susceptible to noise and interference</li>
                <li>Requires higher signal-to-noise ratio (SNR) for the same BER as PSK</li>
            </ul>
        `
    }
};

// Channel theory content
const channelTheoryMap = {
    'AWGN': {
        title: 'Additive White Gaussian Noise (AWGN)',
        content: `
            <h4>AWGN Channel</h4>
            <p>The Additive White Gaussian Noise (AWGN) channel adds white noise with a constant spectral density and a Gaussian distribution of amplitude to the signal.</p>
            
            <h5>Key Characteristics:</h5>
            <ul>
                <li>Noise is additive (added to the signal)</li>
                <li>Noise is white (constant power spectral density)</li>
                <li>Noise has a Gaussian (normal) amplitude distribution</li>
                <li>Modeled as: $r(t) = s(t) + n(t)$</li>
            </ul>
            
            <h5>Effects on Signal:</h5>
            <ul>
                <li>Causes random variations in signal amplitude</li>
                <li>Leads to bit errors in digital communications</li>
                <li>Performance limited by signal-to-noise ratio (SNR)</li>
            </ul>
        `
    },
    'Rayleigh': {
        title: 'Rayleigh Fading Channel',
        content: `
            <h4>Rayleigh Fading Channel</h4>
            <p>Rayleigh fading models wireless communication channels where there is no line-of-sight (NLOS) between transmitter and receiver, and the signal arrives via multiple paths.</p>
            
            <h5>Key Characteristics:</h5>
            <ul>
                <li>Models multipath propagation</li>
                <li>Signal amplitude follows a Rayleigh distribution</li>
                <li>Phase is uniformly distributed</li>
                <li>Modeled as: $r(t) = h(t)s(t) + n(t)$</li>
            </ul>
            
            <h5>Effects on Signal:</h5>
            <ul>
                <li>Causes signal fading (random fluctuations in signal strength)</li>
                <li>Leads to burst errors in digital communications</li>
                <li>More severe impact on performance than AWGN alone</li>
                <li>Performance depends on both SNR and fading statistics</li>
            </ul>
        `
    }
};

// Coding theory content
const codingTheoryMap = {
    'none': {
        title: 'No Channel Coding',
        content: `
            <h4>No Channel Coding</h4>
            <p>In this mode, no forward error correction (FEC) coding is applied to the transmitted data.</p>
            
            <h5>Characteristics:</h5>
            <ul>
                <li>No redundancy added to the data</li>
                <li>Higher data rate (no overhead)</li>
                <li>No error correction capability</li>
                <li>Performance limited by raw channel BER</li>
            </ul>
        `
    },
    'convolutional': {
        title: 'Convolutional Coding',
        content: `
            <h4>Convolutional Coding</h4>
            <p>Convolutional codes are error-correcting codes that generate parity symbols via the sliding application of a boolean polynomial function to a data stream.</p>
            
            <h5>Key Features:</h5>
            <ul>
                <li>Adds redundancy for error correction</li>
                <li>Uses shift registers and XOR operations</li>
                <li>Decoded using the Viterbi algorithm</n                <li>Good for correcting random bit errors</li>
                <li>Adds overhead (e.g., rate 1/2 means double the data)</li>
            </ul>
            
            <h5>Implementation:</h5>
            <p>In this simulation, we use a rate 1/2 convolutional code with constraint length 7 and generator polynomials [171, 133] (octal).</p>
        `
    },
    'reed-solomon': {
        title: 'Reed-Solomon Coding',
        content: `
            <h4>Reed-Solomon Coding</h4>
            <p>Reed-Solomon codes are block-based error correcting codes with a wide range of applications in digital communications and storage.</p>
            
            <h5>Key Features:</h5>
            <ul>
                <li>Non-binary block code</li>
                <li>Excellent for correcting burst errors</li>
                <li>Widely used in CDs, DVDs, QR codes, etc.</li>
                <li>Can correct up to t symbol errors where 2t = n - k</li>
            </ul>
            
            <h5>Implementation:</h5>
            <p>In this simulation, we use a RS(255, 223) code that can correct up to 16 symbol errors per codeword.</p>
        `
    }
};

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    // Initialize UI components
    initTabs();
    initEventListeners();
    updateTheoryContent();
    updateMessageInputState();
    
    // Show home tab by default
    showTab('home');
});

// Initialize tab functionality
function initTabs() {
    tabs.forEach(tab => {
        tab.addEventListener('click', function() {
            const tabId = this.getAttribute('data-tab');
            showTab(tabId);
        });
    });
}

// Show the specified tab and hide others
function showTab(tabId) {
    // Update active tab
    tabs.forEach(tab => {
        if (tab.getAttribute('data-tab') === tabId) {
            tab.classList.add('active');
        } else {
            tab.classList.remove('active');
        }
    });
    
    // Show active tab content
    tabContents.forEach(content => {
        if (content.id === `${tabId}Content`) {
            content.classList.add('active');
        } else {
            content.classList.remove('active');
        }
    });
    
    // Save current tab
    currentTab = tabId;
    
    // Update theory content when switching to simulation tab
    if (tabId === 'simulation') {
        updateTheoryContent();
    }
}

// Initialize event listeners
function initEventListeners() {
    // Form submission
    if (simulationForm) {
        simulationForm.addEventListener('submit', function(e) {
            e.preventDefault();
            runSimulation();
        });
    }
    
    // Reset button
    if (resetBtn) {
        resetBtn.addEventListener('click', resetSimulation);
    }
    
    // SNR slider
    if (snrSlider) {
        snrSlider.addEventListener('input', function() {
            if (snrValue) {
                snrValue.textContent = `${this.value} dB`;
            }
            updateSnrEffect();
        });
    }
    
    // Toggle between random and custom message
    if (useRandomCheckbox) {
        useRandomCheckbox.addEventListener('change', updateMessageInputState);
    }
    
    // Update theory content when modulation changes
    const modulationSelect = document.getElementById('modulation');
    if (modulationSelect) {
        modulationSelect.addEventListener('change', updateTheoryContent);
    }
    
    // Update theory content when channel changes
    const channelSelect = document.getElementById('channel');
    if (channelSelect) {
        channelSelect.addEventListener('change', updateTheoryContent);
    }
    
    // Update theory content when coding changes
    const codingSelect = document.getElementById('coding');
    if (codingSelect) {
        codingSelect.addEventListener('change', updateTheoryContent);
    }
}

// Update message input state based on random message checkbox
function updateMessageInputState() {
    if (messageInput && useRandomCheckbox) {
        messageInput.disabled = useRandomCheckbox.checked;
        if (useRandomCheckbox.checked) {
            messageInput.placeholder = 'Enter custom message (not used in random mode)';
        } else {
            messageInput.placeholder = 'Enter your message here...';
        }
    }
}

// Update theory content based on selected options
function updateTheoryContent() {
    if (!theoryContent) return;
    
    const modulation = document.getElementById('modulation').value;
    const channel = document.getElementById('channel').value;
    const coding = document.getElementById('coding').value;
    
    let html = `
        <div class="theory-section">
            <h3>${theoryContentMap[modulation].title}</h3>
            ${theoryContentMap[modulation].content}
        </div>
        
        <div class="theory-section">
            <h3>${channelTheoryMap[channel].title}</h3>
            ${channelTheoryMap[channel].content}
        </div>
        
        <div class="theory-section">
            <h3>${codingTheoryMap[coding].title}</h3>
            ${codingTheoryMap[coding].content}
        </div>
    `;
    
    theoryContent.innerHTML = html;
    
    // Render any math expressions with MathJax if available
    if (typeof MathJax !== 'undefined') {
        MathJax.typeset();
    }
}

// Update SNR effect visualization
function updateSnrEffect() {
    const snr = parseFloat(snrSlider.value);
    // This is a simplified visualization of SNR effect
    // In a real implementation, you might show sample constellations at different SNRs
    console.log(`SNR updated to ${snr} dB`);
}

// Run the simulation
async function runSimulation() {
    if (isSimulationRunning) return;
    
    try {
        // Set loading state
        isSimulationRunning = true;
        runSimulationBtn.disabled = true;
        runSimulationBtn.innerHTML = '<span class="spinner"></span> Running Simulation...';
        
        // Show loading state in results
        if (resultsContainer) {
            resultsContainer.innerHTML = `
                <div class="alert alert-info">
                    <h4>Running Simulation...</h4>
                    <p>Please wait while we process your simulation. This may take a few moments.</p>
                    <div class="progress">
                        <div class="progress-bar progress-bar-striped progress-bar-animated" style="width: 100%"></div>
                    </div>
                </div>
            `;
        }
        
        // Get form data
        const formData = new FormData(simulationForm);
        const params = {
            modulation: formData.get('modulation'),
            channel: formData.get('channel'),
            coding: formData.get('coding'),
            snr_db: formData.get('snr'),
            use_random: formData.get('useRandom') === 'on',
            message: formData.get('message') || '',
            num_bits: formData.get('numBits') || 1000
        };
        
        // Call the backend API
        const response = await fetch('/simulate', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(params)
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        // Process the response
        simulationResults = await response.json();
        displayResults(simulationResults);
        
    } catch (error) {
        console.error('Error running simulation:', error);
        if (resultsContainer) {
            resultsContainer.innerHTML = `
                <div class="alert alert-danger">
                    <h4>Simulation Error</h4>
                    <p>An error occurred while running the simulation. Please try again.</p>
                    <pre>${error.message}</pre>
                </div>
            `;
        }
    } finally {
        // Reset loading state
        isSimulationRunning = false;
        if (runSimulationBtn) {
            runSimulationBtn.disabled = false;
            runSimulationBtn.textContent = 'Run Simulation';
        }
    }
}

// Display simulation results
function displayResults(results) {
    if (!resultsContainer) return;
    
    // Extract data from results
    const { plots, parameters, metrics } = results;
    
    // Create results HTML
    let html = `
        <div class="results-header">
            <h3>Simulation Results</h3>
            <div class="simulation-params">
                <p><strong>Modulation:</strong> ${parameters.modulation}</p>
                <p><strong>Channel:</strong> ${parameters.channel}</p>
                <p><strong>Coding:</strong> ${parameters.coding || 'None'}</p>
                <p><strong>SNR:</strong> ${parameters.snr_db} dB</p>
            </div>
        </div>
        
        <div class="results-metrics">
            <div class="metric-card">
                <h4>Bit Error Rate (BER)</h4>
                <div class="metric-value">${metrics.ber.toExponential(4)}</div>
                <p>Lower is better (0 is perfect)</p>
            </div>
            
            <div class="metric-card">
                <h4>Bit Error Count</h4>
                <div class="metric-value">${metrics.error_count}</div>
                <p>Out of ${metrics.total_bits} bits</p>
            </div>
            
            <div class="metric-card">
                <h4>Error Vector Magnitude (EVM)</h4>
                <div class="metric-value">${(metrics.evm * 100).toFixed(2)}%</div>
                <p>Lower is better (0% is perfect)</p>
            </div>
        </div>
        
        <div class="results-plots">
            <div class="plot-container">
                <h4>Time Domain</h4>
                <img src="data:image/png;base64,${plots.time_domain}" alt="Time Domain Plot" class="img-fluid">
                <p class="plot-caption">Transmitted (blue) and received (red) signals in the time domain.</p>
            </div>
            
            <div class="plot-container">
                <h4>Constellation Diagram</h4>
                <img src="data:image/png;base64,${plots.constellation}" alt="Constellation Diagram" class="img-fluid">
                <p class="plot-caption">Received symbols (blue) vs. ideal constellation points (red circles).</p>
            </div>
            
            ${plots.ber_vs_snr ? `
            <div class="plot-container">
                <h4>BER vs SNR</h4>
                <img src="data:image/png;base64,${plots.ber_vs_snr}" alt="BER vs SNR" class="img-fluid">
                <p class="plot-caption">Simulated (blue) vs. theoretical (red) BER performance.</p>
            </div>
            ` : ''}
        </div>
        
        <div class="results-analysis">
            <h4>Analysis</h4>
            <p>${getAnalysisText(parameters, metrics)}</p>
            
            <h5>Recommendations</h5>
            <ul>
                ${getRecommendations(parameters, metrics).map(rec => `<li>${rec}</li>`).join('')}
            </ul>
        </div>
    `;
    
    resultsContainer.innerHTML = html;
    
    // Scroll to results
    resultsContainer.scrollIntoView({ behavior: 'smooth' });
}

// Generate analysis text based on simulation results
function getAnalysisText(parameters, metrics) {
    const { modulation, channel, coding, snr_db } = parameters;
    const { ber, error_count, total_bits } = metrics;
    
    let analysis = '';
    
    // General performance assessment
    if (ber === 0) {
        analysis += 'Perfect transmission! No bit errors were detected. ';
    } else if (ber < 1e-6) {
        analysis += 'Excellent performance with very low bit error rate. ';
    } else if (ber < 1e-4) {
        analysis += 'Good performance with low bit error rate. ';
    } else if (ber < 1e-2) {
        analysis += 'Moderate performance with some bit errors. ';
    } else {
        analysis += 'Poor performance with high bit error rate. ';
    }
    
    // Modulation-specific analysis
    if (modulation === 'BPSK') {
        analysis += 'BPSK provides robust performance in noisy conditions but has lower spectral efficiency. ';
    } else if (modulation === 'QPSK') {
        analysis += 'QPSK offers a good balance between spectral efficiency and noise immunity. ';
    } else if (modulation === '16-QAM') {
        analysis += '16-QAM provides high spectral efficiency but requires higher SNR for reliable communication. ';
    }
    
    // Channel-specific analysis
    if (channel === 'AWGN') {
        analysis += 'AWGN channel adds random noise to the signal. ';
    } else if (channel === 'Rayleigh') {
        analysis += 'Rayleigh fading causes signal variations due to multipath propagation. ';
    }
    
    // Coding analysis
    if (coding === 'convolutional') {
        analysis += 'Convolutional coding helps correct random bit errors. ';
    } else if (coding === 'reed-solomon') {
        analysis += 'Reed-Solomon coding is effective against burst errors. ';
    } else {
        analysis += 'No channel coding was used, so no error correction was applied. ';
    }
    
    // SNR analysis
    if (snr_db > 15) {
        analysis += 'The high SNR ensures good signal quality. ';
    } else if (snr_db > 5) {
        analysis += 'The moderate SNR provides acceptable performance. ';
    } else {
        analysis += 'The low SNR results in degraded performance. ';
    }
    
    return analysis;
}

// Generate recommendations based on simulation results
function getRecommendations(parameters, metrics) {
    const { modulation, channel, coding, snr_db } = parameters;
    const { ber } = metrics;
    
    const recommendations = [];
    
    // General recommendations
    if (ber > 1e-4) {
        recommendations.push('Consider increasing the SNR for better performance.');
        
        if (coding === 'none') {
            recommendations.push('Add channel coding (convolutional or Reed-Solomon) to reduce bit errors.');
        } else if (coding === 'convolutional' && channel === 'Rayleigh') {
            recommendations.push('Consider using Reed-Solomon coding which may perform better under fading channels.');
        } else if (coding === 'reed-solomon' && channel === 'AWGN') {
            recommendations.push('Consider using convolutional coding which may be more efficient for AWGN channels.');
        }
        
        if (modulation === '16-QAM' && snr_db < 15) {
            recommendations.push('Consider using QPSK or BPSK for better performance at lower SNRs.');
        }
    }
    
    // Modulation-specific recommendations
    if (modulation === 'BPSK' && snr_db > 15) {
        recommendations.push('Consider using QPSK or 16-QAM for higher data rates at this SNR.');
    } else if (modulation === 'QPSK' && snr_db > 20) {
        recommendations.push('Consider using 16-QAM for higher spectral efficiency at this SNR.');
    } else if (modulation === '16-QAM' && snr_db < 5) {
        recommendations.push('Consider using QPSK or BPSK for better performance at this SNR.');
    }
    
    // If no specific recommendations, add a general one
    if (recommendations.length === 0) {
        recommendations.push('The current configuration is well-suited for the given conditions.');
    }
    
    return recommendations;
}

// Reset the simulation
function resetSimulation() {
    if (confirm('Are you sure you want to reset the simulation? All results will be lost.')) {
        // Reset form
        if (simulationForm) {
            simulationForm.reset();
        }
        
        // Reset results
        if (resultsContainer) {
            resultsContainer.innerHTML = '';
        }
        
        // Reset state
        simulationResults = null;
        
        // Update UI
        if (snrValue) {
            snrValue.textContent = `${snrSlider.value} dB`;
        }
        
        updateMessageInputState();
        updateTheoryContent();
    }
}

// Helper function to format numbers
function formatNumber(num, decimals = 4) {
    return parseFloat(num.toFixed(decimals));
}

// Export results (placeholder for future implementation)
function exportResults(format = 'png') {
    alert(`Exporting results as ${format.toUpperCase()} is not yet implemented.`);
}

// Toggle advanced options (placeholder for future implementation)
function toggleAdvancedOptions() {
    const advancedOptions = document.getElementById('advancedOptions');
    if (advancedOptions) {
        advancedOptions.style.display = advancedOptions.style.display === 'none' ? 'block' : 'none';
    }
}

// Initialize tooltips (if using Bootstrap tooltips)
function initTooltips() {
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
}

// Initialize popovers (if using Bootstrap popovers)
function initPopovers() {
    const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });
}

// Initialize MathJax if available
if (typeof MathJax !== 'undefined') {
    MathJax.Hub.Queue(["Typeset", MathJax.Hub]);
}
